## 2026-07-21 06:45:13.068Z navigate
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/
- via: replaceState

## 2026-07-21 06:45:20.622Z load
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/
- title: Wyzrdy — Founding Access $11.69 for Your First Year | AI Business Operating System

## 2026-07-21 06:45:22.791Z navigate
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/
- via: replaceState

## 2026-07-21 06:45:25.846Z load
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/
- title: Wyzrdy — Founding Access $11.69 for Your First Year | AI Business Operating System

## 2026-07-21 06:52:54.135Z load
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/performance
- title: Wyzrdy — Founding Access $11.69 for Your First Year | AI Business Operating System

## 2026-07-21 06:52:55.136Z navigate
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/
- via: replaceState

## 2026-07-21 06:52:55.136Z navigate
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/
- via: popstate

## 2026-07-21 06:52:55.562Z navigate
- url: https://312e8e7e-e380-4102-ab12-43421672f142.app-preview.com/
- via: replaceState

## 2026-07-21 06:53:08.475Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Yearlysave 50%"}

## 2026-07-21 06:53:14.339Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Monthly"}

## 2026-07-21 06:53:22.323Z click
- element: {"tag":"button","role":null,"ariaLabel":null,"name":null,"type":null,"id":null,"placeholder":null,"label":null,"value":null,"valueLength":0,"text":"Yearlysave 50%"}

